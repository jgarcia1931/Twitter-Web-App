


# Twitter App access keys for @user

# Consume:


CONSUMER_KEY    = 'wbdVCOhmB1Gw8oUSTVen19RdP'
CONSUMER_SECRET = 'oOtj03fLhNBeb4AqxTeGGN76cpOb1iiqj59H2eNli8B737Le8D'
ACCESS_TOKEN    = '881626873-47GUciN7LWOGAECX7xKphUk9IaAX71ODnv8ikcFj'
ACCESS_SECRET   = 'MwlOmN68UrmEJMOIQSTH7jqtp37Zv1JN3sjQxegw1ve8c'







